package main

import (
	"GoScanPlayers/hypixel"
	"GoScanPlayers/player"
	"GoScanPlayers/storage"
	"fyne.io/fyne/v2"
	"fyne.io/fyne/v2/app"
	"fyne.io/fyne/v2/container"
	"fyne.io/fyne/v2/widget"
	"log"
	"strconv"
	"os"
)

func acquireLock() (*os.File, error) {
	lockFile, err := os.OpenFile(
		".goscan.lock",
		os.O_CREATE|os.O_EXCL|os.O_WRONLY,
		0644,
	)
	if err != nil {
		return nil, err
	}
	return lockFile, nil
}

func main() {
	lock, err := acquireLock()
	if err != nil {
		println("Another instance is already running.")
		os.Exit(1)
	}
	defer func() {
		lock.Close()
		os.Remove(".goscan.lock")
	}()

	log.SetFlags(log.LstdFlags | log.Lshortfile)
	storageHandler := storage.New()
	data := storageHandler.GetData()
	a := app.New()
	w := a.NewWindow("Player Scanner")
	playerList := player.GeneratePlayerList(data, w)
	apiKeyEntry := widget.NewEntry()
	apiKeyEntry.SetPlaceHolder("Enter Your Hypixel Api Key Here!")
	if data.ApiKey != "" {
		apiKeyEntry.Text = data.ApiKey
	}
	hypixelLookupChecker := hypixel.New(data, playerList)
	webhookMessage := widget.NewEntry()
	webhookMessage.SetPlaceHolder("Discord Webhook Message Content")
	if data.WebhookContent != "" {
		webhookMessage.Text = data.WebhookContent
	}
	webhookUrl := widget.NewEntry()
	webhookUrl.SetPlaceHolder("Discord Webhook URL")
	if data.WebhookUrl != "" {
		webhookUrl.Text = data.WebhookUrl
	}
	
	requestDelayEntry := widget.NewEntry()
	requestDelayEntry.SetPlaceHolder("Request delay (ms) — minimum 500")
	requestDelayEntry.SetText(strconv.Itoa(data.RequestDelayMs))


	saveConfigButton := widget.NewButton("Save Config", func() {
		data.WebhookUrl = webhookUrl.Text
		data.WebhookContent = webhookMessage.Text
		data.ApiKey = apiKeyEntry.Text

		if delay, err := strconv.Atoi(requestDelayEntry.Text); err == nil && delay >= 500 {
			data.RequestDelayMs = delay
		}

		storageHandler.SaveData()
		hypixelLookupChecker.ApiKeyUpdated()
	})

	masterConfig := container.NewVBox(
		widget.NewLabel("Player Scanner: Config"),
		apiKeyEntry,
		webhookUrl,
		webhookMessage,
		requestDelayEntry,
		saveConfigButton,
	)

	playerNameEntry := widget.NewEntry()
	playerNameEntry.SetPlaceHolder("Player username...")
	playerNoteEntry := widget.NewEntry()
	playerNoteEntry.SetPlaceHolder("Player Note...")
	playerNameConfirm := widget.NewButton("Add Player", func() {
		go playerList.AddPlayer(playerNameEntry.Text, playerNoteEntry.Text)
		playerNameEntry.Text = ""
		playerNoteEntry.Text = ""
		playerNameEntry.Refresh()
		playerNoteEntry.Refresh()
		storageHandler.SaveData()
	})

	playerCountLabel := widget.NewLabel(strconv.Itoa(len(data.Players)))
	playerCountText := container.NewHBox(
		widget.NewLabel("Players Tracking: "),
		playerCountLabel,
	)

	playerInput := container.NewVBox(
		playerNameEntry,
		playerNoteEntry,
		playerNameConfirm,
		playerCountText,
	)

	master := container.NewGridWithRows(3,
		masterConfig,
		playerInput,
		playerList.List,
	)
	playerList.WatchLengthChange(playerCountLabel)
	playerList.SetMaster(master)

	w.SetContent(master)

	w.Resize(fyne.NewSize(800, 600))
	w.ShowAndRun()
}
