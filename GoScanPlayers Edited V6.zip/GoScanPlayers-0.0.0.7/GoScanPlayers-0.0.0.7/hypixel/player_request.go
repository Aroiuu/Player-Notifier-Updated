package hypixel

import (
	"GoScanPlayers/player"
	"GoScanPlayers/storage"
	"GoScanPlayers/webhook"
	"encoding/json"
	"io/ioutil"
	"log"
	"net/http"
	"strconv"
	"time"
)
const maxRateLimitSleep = 90 * time.Second
var requestTimes []time.Time

const ApiUrl = "https://api.hypixel.net"

type RequestMaker struct {
	isRateLimited      bool
	keyIsValid         bool
	rateLimitResetTime time.Time
	data               *storage.Data
	playerIndex        int
	playerList         *player.ListHandler
}

func recordRequest() int {
	now := time.Now()
	requestTimes = append(requestTimes, now)

	cutoff := now.Add(-5 * time.Minute)
	j := 0
	for _, t := range requestTimes {
		if t.After(cutoff) {
			requestTimes[j] = t
			j++
		}
	}
	requestTimes = requestTimes[:j]

	return len(requestTimes)
}


func New(data *storage.Data, list *player.ListHandler) *RequestMaker {
	handler := &RequestMaker{
		isRateLimited:      false,
		keyIsValid:         true,
		rateLimitResetTime: time.Now(),
		data:               data,
		playerIndex:        0,
		playerList:         list,
	}
	go handler.updatePlayersLoop()
	return handler
}

func (handler *RequestMaker) getSleepTime() time.Duration {
	if handler.data.RequestDelayMs <= 0 {
		// Refresh every 1.25s, making 48 req/min
		return 1250 * time.Millisecond
	}
	return time.Duration(handler.data.RequestDelayMs) * time.Millisecond
}

func (handler *RequestMaker) updatePlayersLoop() {
	time.Sleep(5 * time.Second)
	for {
		if handler.isRateLimited {
    			sleepTime := time.Until(handler.rateLimitResetTime)

    			if sleepTime <= 0 {
        			sleepTime = 10 * time.Second
    			}

    			if sleepTime > maxRateLimitSleep {
        			log.Printf(
            				"Rate limited sleep too long (%v), clamping to %v\n",
            				sleepTime,
            				maxRateLimitSleep,
        			)
        			sleepTime = maxRateLimitSleep
    			}

    			log.Printf("Rate limited, sleeping for %v\n", sleepTime)
    			time.Sleep(sleepTime)

    			handler.isRateLimited = false
		}

		for !handler.keyIsValid || len(handler.data.Players) == 0 {
			time.Sleep(5 * time.Second)
		}
		playerObject := handler.data.Players[handler.playerIndex]
		loginText := handler.CheckPlayerOnline(playerObject.Uuid, handler.data.ApiKey)
		if playerObject.LastSuccessfulStatus != loginText {
			playerObject.OnlineStatus = loginText
			playerObject.IsOnline = loginText[:6] == "ONLINE"
			if loginText != "RATE LIMITED" {
				go webhook.PostDataToURL(handler.data.WebhookUrl, handler.data.WebhookContent, playerObject, playerObject.LastSuccessfulStatus)
			}

			if loginText[:6] == "ONLINE" || loginText[:7] == "OFFLINE" {
				playerObject.LastSuccessfulStatus = loginText
			}
		}
		handler.data.Parent.SaveData()
		playerObject.OnlineLabel.Text = loginText
		playerObject.OnlineLabel.Refresh()
		handler.playerList.ReloadList()
		time.Sleep(handler.getSleepTime())
		handler.playerIndex++
		if handler.playerIndex >= len(handler.data.Players) {
			handler.playerIndex = 0
		}
	}
}

type StatusRequestResponse struct {
	Success bool            `json:"success"`
	Cause   string          `json:"cause"`
	Uuid    string          `json:"uuid"`
	Session SessionResponse `json:"session"`
}

type SessionResponse struct {
	Online   bool   `json:"online"`
	GameType string `json:"gameType"`
	Mode     string `json:"mode"`
}

func (handler *RequestMaker) CheckPlayerOnline(uuid string, apiKey string) string {
	resp, err := http.Get(ApiUrl + "/status?uuid=" + uuid + "&key=" + apiKey)
	if err != nil {
	log.Println("error fetching data from hypixel:", err)
	return "ERROR"
	}
	defer resp.Body.Close()
	if resp.StatusCode == 403 {
		handler.keyIsValid = false
		return "INVALID KEY"
	}
	if resp.StatusCode == 429 {
    		handler.isRateLimited = true

    		const maxBackoff = 90 * time.Second

		if resp.StatusCode == 429 {
    			handler.isRateLimited = true

    			backoff := 60 * time.Second // default

    			if retry := resp.Header.Get("Retry-After"); retry != "" {
        			if seconds, err := strconv.ParseInt(retry, 10, 64); err == nil {
            				backoff = time.Duration(seconds) * time.Second
        			}
    			}

    			if backoff > maxBackoff {
        			log.Printf("Retry-After too large (%v), clamping to %v\n", backoff, maxBackoff)
        			backoff = maxBackoff
    			}

    			handler.rateLimitResetTime = time.Now().Add(backoff)
    			return "RATE LIMITED"
		}

    		return "RATE LIMITED"
	}
	count := recordRequest()
	log.Printf("Hypixel API usage: %d / 300 (last 5 min)", count)
	data := &StatusRequestResponse{}
	byteData, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Fatal(err)
	}
	err = json.Unmarshal(byteData, data)
	if err != nil {
		log.Println("error unmarshalling json:", err)
		return "ERROR"
	}

	if !data.Success {
		return data.Cause
	}
	if data.Session.Online {
		return "ONLINE - " + data.Session.GameType + " - " + data.Session.Mode
	} else {
		return "OFFLINE"
	}
}

func (handler *RequestMaker) ApiKeyUpdated() {
	handler.keyIsValid = true
}
