# GoScanPlayers
Hypixel online player tracker. Runs as an executable and can notify a Discord Webhook

## Example Config
![Example](https://thom.club/SVl0ADY.png)

## Example Webhook
![Example Webhook](https://thom.club/L9SUbqI.png)
